BEGIN;

do $$
DECLARE
	given_flight_id VARCHAR(5) := 'AT128'; 
	given_timestamp TIMESTAMP := '2021-08-18 14:00:00';
begin


UPDATE Flight SET actual_departure = given_timestamp WHERE flight_id = given_flight_id AND actual_departure IS NULL;


end; $$;

COMMIT;
