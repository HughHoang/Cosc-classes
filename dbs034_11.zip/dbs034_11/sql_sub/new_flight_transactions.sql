
BEGIN TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

do $$
DECLARE 
	possible_departure_gate VARCHAR(6) := 'DENNES';
	possible_arrival_gate VARCHAR(6) := 'LAXNEG';
	possible_departure_time TIMESTAMP := '2021-08-20 10:00:40';
	possible_arrival_time TIMESTAMP := '2021-08-20 15:00:00';
	possible_food VARCHAR(20) := 'CHICKEN';
	possible_check_in TIMESTAMP := '2021-08-20 8:00:00';
	currentFlightID VARCHAR(5) := 'BC456';
	

/*the above variables should be inserted by the website user, these are harcoded in for readability and debugging, remove these declerations and instead use variables from JS*/

	possiblePilot INTEGER := 635;
	possibleCopilot INTEGER := 917;
	possibleCleaner INTEGER := 459;

	p_status VARCHAR(10) := 'ONTIME';
	flightAircraft VARCHAR(4) := '-';
	Taken_Count INTEGER := -1;
	validOrder BOOLEAN := True;
	validCheckIn BOOLEAN := True;
begin

/*This checks ans ensures the departure is before arrival*/
IF (possible_departure_time - possible_arrival_time) > '0 seconds' THEN validOrder := False; END IF;
	IF (possible_check_in - possible_departure_time) < '-4 hours' OR (possible_check_in - possible_departure_time) > '-1 hour' THEN validCheckIN := False; END IF;

/*This is to find an aircraft for the flight
SELECT aircraft_code into flightAircraft
            FROM (SELECT Aircraft.aircraft_code
	FROM Aircraft, Flight
	WHERE (Aircraft.aircraft_code != Flight.aircraft_code OR (scheduled_arrival - possible_departure_time) = '1 day' OR (scheduled_arrival - possible_departure_time)= '-1 day' ) LIMIT 1)
	AS aircraft_Test;*/

SELECT aircraft_code INTO flightAircraft
FROM Aircraft
EXCEPT
SELECT aircraft_code
FROM(	SELECT aircraft_code, scheduled_arrival
	FROM Flight) as aircraftTest 
WHERE (scheduled_arrival - possible_departure_time) < '1 day' AND (scheduled_arrival - possible_departure_time) > '-1 day'
LIMIT 1;

SELECT crew_id INTO possiblePilot
FROM Crew
WHERE role = 'Pilot'
EXCEPT
SELECT pilot_id
FROM (	SELECT pilot_id, scheduled_arrival
	FROM Flight) as pilotTest
WHERE (scheduled_arrival - possible_departure_time) < '1 day' AND (scheduled_arrival - possible_departure_time) > '-1 day'
LIMIT 1;

SELECT crew_id INTO possibleCopilot
FROM Crew
WHERE role = 'Copilot'
EXCEPT
SELECT copilot_id
FROM(	SELECT copilot_id, scheduled_arrival
	FROM FLight) as copilotTest
WHERE (scheduled_arrival - possible_departure_time) < '1 day' AND (scheduled_arrival - possible_departure_time) > '-1 day'
LIMIT 1;

SELECT crew_id INTO possibleCleaner
FROM CREW
WHERE role = 'Cleaner'
EXCEPT
SELECT cleaner_id
FROM(	SELECT cleaner_id, scheduled_arrival
	FROM Flight) as cleanerTest
WHERE (scheduled_arrival - possible_departure_time) < '1 day' AND (scheduled_arrival - possible_departure_time) > '-1 day'
LIMIT 1;

SELECT COUNT(*) into Taken_Count 
	FROM (SELECT flight_id
		FROM Flight
		WHERE (departure_gate_number = possible_departure_gate
			AND ((possible_departure_time - scheduled_departure) <= '1 hour' AND (possible_departure_time - scheduled_departure) >= '-1 hour'))
			OR (arrival_gate_number = possible_arrival_gate
			AND ((possible_arrival_time - scheduled_arrival) <= '1 hour' AND (possible_arrival_time - scheduled_arrival) >= '-1 hour'))) AS invalid_flight;

IF Taken_Count = 0 AND validOrder = TRUE AND validCheckIn = True THEN
		INSERT INTO Flight
			VALUES (currentFlightID, flightAircraft, possible_departure_time, possible_arrival_time, possible_food, possible_check_in, possible_arrival_gate, possible_departure_gate, p_status, NULL, NULL, possiblePilot, possibleCopilot, possibleCleaner);
END IF;

end;
$$;

COMMIT TRANSACTION;



