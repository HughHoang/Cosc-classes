/*This transaction is unable to be used until the database is updated to support NULL check_in values*/

BEGIN;

do $$
DECLARE
	given_ticket_no INTEGER := 100001;
	given_timestamp TIMESTAMP := '2020-08-09 12:00:00';

begin
	UPDATE Tickets SET check_in = given_timestamp WHERE ticket_no = given_ticket_no;
end; $$;

COMMIT;
